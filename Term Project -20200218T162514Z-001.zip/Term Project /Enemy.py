import pygame 
from GameObject import GameObject 
import random 

class Enemy(GameObject):
    def __init__(self, x, y, image, radius):
        super().__init__(x, y, image, 30)
        self.screenHeight = y
        self.screenWidth = x
        self.speed = 20 
        self.y = 480
        self.x = self.screenWidth
        self.timer = 0
        self.scrollX = 1
        
    def move(self):
        self.x -= self.scrollX
        
    def update(self, screenWidth, screenHeight):
        super(Enemy, self).update(screenWidth, screenHeight)
        
class Boss(Enemy):
    def __init__(self, x, y, image, radius):
        super().__init__(x, y, image, 30)
        self.y = 20  
        self.bossMoved = 0 
        
    def moveOnPath(self, shortestPath):
        for move in shortestPath:
            if self.bossMoved < 5:
                self.bossMoved += 1 
                self.x += move[0]
                self.y += move[1]
        self.bossMoved = 0
        
    def update(self, screenWidth, screenHeight):
        super(Enemy, self).update(screenWidth, screenHeight)
        
    