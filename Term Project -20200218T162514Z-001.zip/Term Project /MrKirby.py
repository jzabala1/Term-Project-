import pygame
from GameObject import GameObject 

class Char(GameObject):        
    def __init__(self, x, y, image, radius):
        super().__init__(x, y, image, 30)
        self.screenWidth = x
        self.speed = 5
        self.grassY = 500
        self.y = self.grassY - 20 
        self.x = self.screenWidth//10
        self.gravity = 2
        self.jumpH = 70
        self.keyRight = None
        self.keyLeft = None
        
    def update(self, keysDown, screenWidth, screenHeight):
        self.keyRight = keysDown(pygame.K_RIGHT)
        self.keyLeft = keysDown(pygame.K_LEFT)
        super(Char, self).update(screenWidth, screenHeight)

    
    
