import pygame 
from GameObject import GameObject 
import random 

class Obstacle(GameObject):
    def __init__(self, x, y, image, radius):
        super().__init__(x, y, image, 30)
        self.scroll = 1.25
        
    def move(self):
        self.x -= self.scroll

    def update(self, screenWidth, screenHeight):
        super(Obstacle, self).update(screenWidth, screenHeight)

        
class MovingObstacle(Obstacle):
    def __init__(self, x, y, image, radius):
        super().__init__(x, y, image, 30)
        self.scroll = 1
        self.screenWidth = 900
        self.screenHeight = 600
                
    def moveY(self):
        self.y += self.scroll
        
    def moveUpAndDown(self):
        if self.y <= 50 or self.y >= 480:
            self.scroll = -self.scroll 
            
class House(Obstacle):
    def __init__(self, x, y, image, radius):
        super().__init__(x, y, image, 30)
        self.x = 450 
        self.y = 450 

    def update(self, screenWidth, screenHeight):
        super(Obstacle, self).update(screenWidth, screenHeight)

    
