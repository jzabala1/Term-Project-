import pygame
from MrKirby import Char
from pygamegame import PygameGame
from Enemy import Enemy
from Obstacle import Obstacle 
from Enemy import Boss 
import random 

#from 15-112 pygame manual framework 
class Game(PygameGame):
    def init(self):
        #establishing game objects 
        self.obsImage = pygame.transform.scale(
            pygame.image.load('platform.png').convert_alpha(),
            (100, 100)) 
        self.enemyImage = pygame.transform.scale(
            pygame.image.load('Kirby Enemy.png').convert_alpha(),
            (70, 70)) 
        self.skyImage = pygame.transform.scale(
            pygame.image.load('sky.jpg').convert_alpha(),
            (self.width, self.height)) 
        self.sunflowerImage = pygame.transform.scale(
            pygame.image.load('sunflower.png').convert_alpha(),
            (50, 50)) 
        self.sunImage = pygame.transform.scale(
            pygame.image.load('sun.png').convert_alpha(),
            (100, 100)) 
        self.boss = Boss(self.width, self.height, self.sunImage, 30)
        self.enemy = pygame.sprite.Group()
        self.obstacleGroup = pygame.sprite.Group()
        self.sunflowerGroup = pygame.sprite.Group()
        self.sun = pygame.sprite.GroupSingle()
        self.timer = 0
        self.kirbyHearts = [0] * 3
        self.lose = False 
        self.win = False 
        self.heartImage = pygame.transform.scale(
            pygame.image.load('heart.png'),
            (70, 70))
        self.questionMark = pygame.transform.scale(
            pygame.image.load('questionMark.png'),
            (40, 40))
        self.groundY = 500
        self.obstacles = []
        self.obsHeight = 0
        self.oldObsHeight = 0
        self.onGround = True
        self.isPaused = True 
        self.startMenu = True 
        self.help = False
        self.enemies = []
        self.sunflowers = []
        self.sunCount = 0
        self.bossOnScreen = False
        self.bossAlive = False 
        self.inGameHelp = False 
        self.playerSelect = False 
        #powerUp stuff
        self.candyImage = pygame.transform.scale(
            pygame.image.load('candy.png').convert_alpha(),
            (50, 50)) 
        self.candies = []
        self.candyGroup = pygame.sprite.GroupSingle()
        self.ammo = 0
        self.buyMenu = False 
        self.invincibilty = False 
    
    def winningGame(self):
        if self.timer == 4000:
            self.win = True 
        
    def losingGame(self):
        if len(self.kirbyHearts) == 0:
            self.lose = True
            
    def mousePressed(self, x, y):
        if self.isPaused:
            print(pygame.mouse.get_pos())
            #pressing play on the start Menu 
            if self.startMenu == True and (self.width//2 - 70 <= x <= \
            self.width//2 + 70) and (self.height//2 - 40 <= y <= \
             self.height//2 + 40):
                self.playerSelect = True 
            #pressing how to play in start
            elif self.startMenu == True and (self.width//2 - 100 <= x <= \
            self.width//2 + 100) and (self.height//2 + 80 <= y <= \
             self.height//2 + 220):
                self.help = True 
            #pressing main menu on help screen 
            elif self.help == True and (self.width//2 + 130 <= x <= \
            self.width//2 + 300) and (self.height//2 - 20 <= y <= \
             self.height//2 + 20):
                self.help = False
            #pressing back on help screen(question mark)
            elif self.inGameHelp == True and (self.width//2 + 130 <= x <= \
            self.width//2 + 300) and (self.height//2 - 20 <= y <= \
             self.height//2 + 20):
                self.isPaused = False 
                self.inGameHelp = False
            #pressing main menu on help screen(question mark)
            elif self.inGameHelp == True and (self.width//2 - 100 <= x <= \
            self.width//2 + 100) and (85 <= y <= 120):
                self.startMenu = True
                self.inGameHelp = False 
            #player selection 
            elif self.playerSelect and (self.width//2 - 300 <= x <= \
            self.width//2 - 170) and (self.height//2 + 10 <= y <= \
             self.height//2 + 130):
                self.playerImage = pygame.transform.scale(
            pygame.image.load('kirby.png').convert_alpha(),
            (70, 70))
                self.isPaused = False 
                self.playerSelect = False 
                self.player = Char(self.width, self.height, self.playerImage, 
                30)
                self.charGroup = pygame.sprite.GroupSingle(self.player)
            elif self.playerSelect and (self.width//2 + 200 <= x <= \
            self.width//2 + 350) and (self.height//2 <= y <= \
             self.width//2):
                self.playerImage = pygame.transform.scale(
            pygame.image.load('Hat Kirby.png').convert_alpha(),
            (70, 70))
                self.isPaused = False 
                self.playerSelect = False
                self.player = Char(self.width, self.height, self.playerImage, 
                30)
                self.charGroup = pygame.sprite.GroupSingle(self.player)
            #buying menu 
            elif self.inGameHelp and (415 <= x <= 490) and (480 <= y <= 520) \
            and self.ammo >= 5:
                self.buyMenu = True 
                self.inGameHelp = False 
            elif self.buyMenu and (240 <= x <= 660) and (25 <= y <= 50) and \
            len(self.kirbyHearts) < 3:
                self.kirbyHearts.append(0)
                self.ammo -= 5
                self.buyMenu = False 
                self.isPaused = False 
            elif self.buyMenu and (190 <= x <= 700) and (280 <= y <= 320) and \
            self.ammo >= 10:
                self.ammo -= 10 
                self.invincibilty = True 
                self.buyMenu = False 
                self.isPaused = False 
            
        #pressing the question mark 
        if self.isPaused == False:
            if 0 <= x <= 50 and 0 <= y <= 50:
                self.startMenu = False 
                self.isPaused = True 
                self.inGameHelp = True 
                
    def playerSelectScreen(self,screen):
        pygame.draw.rect(screen, (176,224,230), (0, 0,
         self.width, self.height))
        hatKX = self.width//2 + 200
        hatKY = self.height//2 
        hatKImage = pygame.transform.scale(
            pygame.image.load('Hat Kirby.png').convert_alpha(),
            (150, 150))
        screen.blit(hatKImage, (hatKX, hatKY))
        kX = self.width//2 - self.width//3
        kY = self.height//2
        kImage= pygame.transform.scale(
            pygame.image.load('kirby.png').convert_alpha(),
            (150, 150))
        screen.blit(kImage, (kX, kY))
        font = pygame.font.Font(None, 50)
        choosingText = font.render("Choose Your Kirby", 1, (255, 255, 255))
        choosingTextPos = choosingText.get_rect(centerx=self.width/2,
                centery=self.height//4)
        screen.blit(choosingText, choosingTextPos)
        
    def keyPressed(self, keyCode, modifier):
        #jumping
        if keyCode == 32:
            self.player.y -= self.player.jumpH 
            self.onGround = False
            
    def checkDistance(self, height):
        if len(self.obstacles) > 0 and self.obsHeight < 510 and \
        self.player.jumpH//2 <= (abs(self.obsHeight - height)) \
        <= self.player.jumpH:
            self.oldObsHeight = self.obsHeight
            return True 
        else:
            return False 
            
    def moveX(self):
        if self.player.keyRight:
            self.player.x += self.player.speed
        if self.player.keyLeft:
            self.player.x -= self.player.speed
    
    def createObstacle(self):
        self.sunCount += 1
        if len(self.obstacles) == 0:
            self.obsHeight = 420
            self.obstacles += [Obstacle(self.width + 50, 
             self.obsHeight, self.obsImage, 30)]
            self.oldObsHeight = self.obsHeight
        else:
            self.obsHeight = random.randint(self.height//4, 
            self.groundY - self.player.jumpH)
            while Game.checkDistance(self, self.oldObsHeight) == False:
                oldObsHeight = self.obsHeight
                self.obsHeight = random.randint(self.height//4, 
                self.groundY - self.player.jumpH)
            self.obstacles += [Obstacle(self.width + 50, self.obsHeight, 
            self.obsImage, 30)]
            if self.sunCount % 10 == 0:
                self.sunflowers += [Obstacle(self.width + 50, 
                self.obsHeight - 50, self.sunflowerImage, 30)]
             
    #pathfinding enemy AI
    def distance(currNode, endNode):
        x1 = currNode[0]
        x2 = endNode[0]
        y1 = currNode[1]
        y2 = endNode[1]
        dis = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
        return dis 
        
    def bestMove(self, currNode, bestPath, move, endNode, bestMove):
        if Game.distance(currNode, endNode) < bestPath[1] and bestPath[1] != \
        100000:
            bestPath[1] = Game.distance(currNode, endNode)
            bestMove = move 
        elif Game.distance(currNode, endNode) < bestPath[1]:
            bestPath[1] = Game.distance(currNode, endNode)
        return bestMove
        
    def makeNextMove(self, currNode, endNode, bestPath):
        speed = 10
        jumpH = 10
        possibleEnemyMoves = [(0, jumpH), (-speed, jumpH), (speed, jumpH),
        (speed, -jumpH), (-speed, -jumpH), (speed, 0), (-speed, 0), (0, -jumpH)]
        bestMove = (0, 0)
        for move in possibleEnemyMoves:
            nextNode = [currNode[0] + move[0], currNode[1] + move[1]]
            bestMove = Game.bestMove(self, nextNode, bestPath, move, endNode, 
            bestMove)
        bestPath[0] += [bestMove]
        while not 0 <= Game.distance(currNode, endNode) <= 10:
            currNode = [currNode[0] + bestMove[0], currNode[1] + bestMove[1]]
            for move in possibleEnemyMoves:
                nextNode = [currNode[0] + move[0], currNode[1] + move[1]]
                bestMove = Game.bestMove(self, nextNode, bestPath, move, 
                endNode, bestMove)
            bestPath[0] += [bestMove]
        return bestPath
          
    def pathFinding(self, enemy):
        bestPath = [[], 100000]
        currNode = [enemy.x, enemy.y]
        endNode = [self.player.x, self.player.y]
        if  not 0 <= Game.distance(currNode, endNode) <= 10:
            bestPath = Game.makeNextMove(self, currNode, endNode, bestPath)
        return bestPath[0]
        
    #proximity chase enemy AI 
    def proximityChase(self,enmy):
        speed = 2.5
        if (self.player.x - 200 <= enmy.x <= self.player.x + 200) and \
        (400 <= self.player.y <= 520):
            if self.player.x < enmy.x:
                enmy.x -= speed 
            elif self.player.x > enmy.x:
                enmy.x += speed 
        else:
            enmy.move()
        
    def timerFired(self, dt):
        if not self.isPaused:
            Game.moveX(self)
            #ground check and gravity 
            if self.player.y > self.groundY - 20: 
                self.player.y = self.groundY - 20
            if self.onGround == False:
                self.player.y += self.player.gravity 
            if self.player.y < 0:
                self.player.y = 0 
            self.timer += 1
            #walls 
            if self.player.x - 30 < 0:
                self.player.x = 30
            elif self.player.x + 30 > self.width:
                self.player.x = self.width - 30
            #creating and moving enemy 
            if self.timer % 500 == 0 and self.bossOnScreen == False:
                self.enemies += [Enemy(self.width + 50, self.height, 
                self.enemyImage, 30)]
            for enmy in self.enemies:
                self.enemy.add(enmy)
                Game.proximityChase(self, enmy)
            #enemy collisions
            if self.invincibilty == False:
                if pygame.sprite.groupcollide(self.charGroup, self.enemy,
                True, False, pygame.sprite.collide_circle) and \
                len(self.kirbyHearts) > 0: 
                    self.player = Char(50, self.groundY, self.playerImage, 30)
                    self.charGroup.add(self.player)
                    self.kirbyHearts.pop()        
            #obstacles 
            if self.timer % 90 == 0 and not self.bossOnScreen:
                Game.createObstacle(self)
            for obs in self.obstacles:
                self.obstacleGroup.add(obs)
                obs.move()
                if (obs.y - 52 <= self.player.y <= obs.y - 50) and \
                (obs.x - 50 <= self.player.x <= obs.x + 50):
                    self.onGround = True 
                if not (obs.y - 52 <= self.player.y <= obs.y - 50) and \
                (obs.x - 50 <= self.player.x <= obs.x + 50):
                    self.onGround = False 
            #sunflowers
            for sun in self.sunflowers:
                self.sunflowerGroup.add(sun)
                sun.move()
            if self.invincibilty == False:
                if pygame.sprite.groupcollide(self.charGroup, 
                self.sunflowerGroup, True, False, pygame.sprite.collide_circle)\
                 and len(self.kirbyHearts) > 0:
                    self.player = Char(50, self.groundY, self.playerImage, 30)
                    self.charGroup.add(self.player)
                    self.kirbyHearts.pop()    
            #boss 
            if self.timer == 3000:
                self.bossOnScreen = True
                self.bossAlive = True 
                self.sun.add(self.boss)
            if self.bossOnScreen  and self.timer % 50 == 0: 
                shortestPath = Game.pathFinding(self, self.boss)
                self.boss.moveOnPath(shortestPath)
            if self.invincibilty == False:
                if pygame.sprite.groupcollide(self.charGroup, self.sun,
                True, False, pygame.sprite.collide_circle) and \
                len(self.kirbyHearts) > 0:
                    self.player = Char(50, self.groundY, self.playerImage, 30)
                    self.charGroup.add(self.player)
                    self.kirbyHearts.pop()  
            #candy
            if self.timer % 300 == 0 and self.candies == []:
                randX = random.randint(0, self.width)
                randY = random.randint(0, 480)
                self.candies += [Obstacle(randX, randY, self.candyImage, 30)]
            for candy in self.candies:
                self.candyGroup.add(candy)
            if pygame.sprite.groupcollide(self.charGroup, self.candyGroup,
            False, True, pygame.sprite.collide_circle) and \
            len(self.kirbyHearts) > 0:
                self.ammo += 1
                self.candies = []
                self.candyGroup = pygame.sprite.GroupSingle()   
            if self.invincibilty and self.timer % 500 == 0:
                self.invincibilty = False 
            #update
            self.charGroup.update(self.isKeyPressed, self.width, self.height)
            self.enemy.update(self.width, self.height)
            self.obstacleGroup.update(self.width, self.height)
            self.sunflowerGroup.update(self.width, self.height)
            self.sun.update(self.width, self.height)
            self.candyGroup.update(self.width, self.height)
            
    def startMenu(self, screen):
        pygame.draw.rect(screen, (255,182,193), (0, 0,
         self.width, self.height))
        font = pygame.font.Font(None, 100)
        startText = font.render("Play", 1, (255, 255, 255))
        startTextPos = startText.get_rect(centerx=self.width/2,
         centery=self.height/2)
        screen.blit(startText, startTextPos)
        smallerFont = pygame.font.Font(None, 50)
        howToPlayText = smallerFont.render("How to Play", 1, (255, 255, 255))
        howToPlayTextPos = howToPlayText.get_rect(centerx=self.width/2,
         centery=self.height/2 + 100)
        screen.blit(howToPlayText, howToPlayTextPos)
        
    def helpMenu(self, screen):
        pygame.draw.rect(screen, (176,224,230), (0, 0,
         self.width, self.height))
        font = pygame.font.Font(None, 50)
        helpText = font.render("Help", 1, (255, 255, 255))
        helpTextPos = helpText.get_rect(centerx=self.width/4,
         centery=self.height/2)
        screen.blit(helpText, helpTextPos)
        startMenuText = font.render("Main Menu", 1, (255, 255, 255))
        startMenuTextPos = startMenuText.get_rect(centerx=self.width/2 +\
         self.width/4, centery=self.height/2)
        screen.blit(startMenuText, startMenuTextPos)
        
    def questionMark(self, screen):
        pygame.draw.rect(screen,(155,205,155) , (0, 0,
         self.width, self.height))
        font = pygame.font.Font(None, 50)
        helpText = font.render("Help", 1, (255, 255, 255))
        helpTextPos = helpText.get_rect(centerx=self.width/4,
         centery=self.height/2)
        screen.blit(helpText, helpTextPos)
        backText = font.render("Back", 1, (255, 255, 255))
        backTextPos = backText.get_rect(centerx=self.width/2 +\
         self.width/4, centery=self.height/2)
        screen.blit(backText, backTextPos)
        mainMenuText = font.render("Main Menu", 1, (255, 255, 255))
        mainMenuTextPos = mainMenuText.get_rect(centerx=self.width/2 , 
        centery=100)
        screen.blit(mainMenuText, mainMenuTextPos)
        font = pygame.font.Font(None, 50)
        buyText = font.render("Buy", 1, (255, 255, 255))
        buyTextPos = buyText.get_rect(centerx=self.width//2,
                centery=500)
        screen.blit(buyText, buyTextPos)
    
    def buyMenu(self, screen):
        pygame.draw.rect(screen,(205,150,205), (0, 0,
         self.width, self.height))
        font = pygame.font.Font(None, 50)
        heartText = font.render("Buy Hearts for 5 Candies", 1, (255, 255, 255))
        heartTextPos = heartText.get_rect(centerx=self.width/2,
         centery=40)
        screen.blit(heartText, heartTextPos)
        bigHeart = pygame.transform.scale(
            pygame.image.load('heart.png'),
            (100, 100))
        bigHeart.set_colorkey((255,255,255))
        screen.blit(bigHeart, (self.width/2 - 40, 80))
        otherText = font.render("Buy Invincibility for 10 Candies", 1,
         (255, 255, 255))
        otherTextPos = heartText.get_rect(centerx=self.width/2 - 50,
         centery=self.height/2)
        screen.blit(otherText, otherTextPos)
        screen.blit(bigHeart, (self.width/2 - 40, 340))
        screen.blit(bigHeart, (self.width/2 - 120, 340))
        screen.blit(bigHeart, (self.width/2 + 40 ,340 ))
    
    def redrawAll(self, screen):
        if self.isPaused == False:
            screen.blit(self.skyImage, (0, 0))
            pygame.draw.rect(screen, (62,99,52), (0, self.groundY ,
                 self.width, self.height))
            font = pygame.font.Font(None, 50)
            ammoText = font.render(str(self.ammo), 1, (0, 0, 0))
            ammoTextPos = ammoText.get_rect(centerx=self.width/2,
                centery=30)
            screen.blit(ammoText, ammoTextPos)
            #drawing characters 
            self.charGroup.draw(screen)
            self.enemy.draw(screen)
            self.obstacleGroup.draw(screen) 
            self.sunflowerGroup.draw(screen)
            self.sun.draw(screen)
            self.candyGroup.draw(screen)
            #lives 
            if len(self.kirbyHearts) > 0:
                for i in range(len(self.kirbyHearts)):
                    heartX = self.width - 150 + i*40
                    heartY = 10
                    self.heartImage.set_colorkey((255,255,255))
                    screen.blit(self.heartImage, (heartX, heartY))
            questionX = 5
            questionY = 5
            screen.blit(self.questionMark, (questionX,questionY))
            pygame.display.flip()
            #losing and winning
            Game.losingGame(self)
            Game.winningGame(self)
        if self.lose:
            pygame.draw.rect(screen, (0,0,0), (0, 0,
                self.width, self.height))
            font = pygame.font.Font(None, 50)
            losingText = font.render("You Lost!", 1, (255, 255, 255))
            losingTextPos = losingText.get_rect(centerx=self.width/2,
                centery=self.height/2)
            screen.blit(losingText, losingTextPos)
            self.startMenu = False 
            self.isPaused = True 
        elif self.win:
            pygame.draw.rect(screen, (0,0,0), (0, 0,
                self.width, self.height))
            font = pygame.font.Font(None, 50)
            losingText = font.render("You Win!", 1, (255, 255, 255))
            losingTextPos = losingText.get_rect(centerx=self.width/2,
                centery=self.height/2)
            screen.blit(losingText, losingTextPos)
            self.startMenu = False 
            self.isPaused = True 
        #start screen 
        if self.isPaused and self.startMenu == True:
            Game.startMenu(self, screen)
        if self.help == True:
            Game.helpMenu(self, screen)
        if self.inGameHelp == True:
            Game.questionMark(self, screen)
        if self.playerSelect == True:
            Game.playerSelectScreen(self, screen)
        if self.buyMenu:
            Game.buyMenu(self,screen)
        pygame.display.flip()
            
Game(900, 600).run()

